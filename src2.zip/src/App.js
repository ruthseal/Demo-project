import logo from './logo.svg';
import './App.css';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import DynamicTable from "./DynamicTable";





function App() {
  return (
    <DynamicTable />
  );
}



export default App;
