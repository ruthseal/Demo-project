import { Component, OnInit } from '@angular/core';
import { combineLatest, withLatestFrom, switchMap,  forkJoin, Observable, of, Subscriber } from 'rxjs';

@Component({
  selector: 'app-combinelatest',
  templateUrl: './combinelatest.component.html',
  styleUrls: ['./combinelatest.component.scss']
})
export class CombineLatest implements OnInit {
  
  constructor() { }
 
  ngOnInit(): void {
	
    
	const weight = of(1, 2, 3);
	const height = of(4, 5);
	const bmi = combineLatest([weight, height], (w, h) => {
	return (w + h);
});
	bmi.subscribe(res => console.log('Combine-Latest is ' + res));
	
	
	let srcObservable= of(1,2,3,4)
	let innerObservable= of('A','B','C','D')
	srcObservable.pipe(
	  switchMap( val => {
		console.log('Main '+val)
		
		return innerObservable
	  })
	)
	.subscribe(ret=> {
	  console.log('Inner ' + ret);
	})
	
	
	const res = weight.pipe(
	withLatestFrom(height, (w, h) => {
	return (h + w);
	}));
	res.subscribe(res => console.log('With-Latest is ' + res));
	
	
  }
}

