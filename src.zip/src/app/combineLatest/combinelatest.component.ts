import { Component, OnInit } from '@angular/core';
import { combineLatest, withLatestFrom,interval, take, timer ,switchMap,  forkJoin, Observable, of, Subscriber } from 'rxjs';

@Component({
  selector: 'app-combinelatest',
  templateUrl: './combinelatest.component.html',
  styleUrls: ['./combinelatest.component.scss']
})
export class CombineLatest implements OnInit {
  
  constructor() { }
 
  ngOnInit(): void {
	
    
	const weight = of(1, 2, 3);
	const height = of(20, 21);
	const bmi = combineLatest([weight, height], (w, h) => {
	return (w + h);
});
	bmi.subscribe(res => console.log('Combine-Latest is ' + res));
	
	
	let srcObservable= of(1,2)
	let innerObservable= of('A','B')
	srcObservable.pipe(
	  switchMap( val => {
		console.log('Main '+val)
		
		return innerObservable
	  })
	)
	.subscribe(ret=> {
	  console.log('Inner ' + ret);
	})
	
	
	
	
	const res = weight.pipe(
	withLatestFrom(height, (w, h) => {
	return (h + w);
	}));
	res.subscribe(res => console.log('With-Latest is ' + res));
	
	const source = timer(1000, 2000);
	const subscribe = source.subscribe(val => console.log(val));
	
	const numbers = interval(1000);
	const takeFourNumbers = numbers.pipe(take(3));
	takeFourNumbers.subscribe(x => console.log('Interval: ', x));

  }
}

