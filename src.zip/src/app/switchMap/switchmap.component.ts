
import { Component } from "@angular/core";
import {
  mergeMap,
  flatMap,
  concatMap,
  switchMap,
  exhaustMap,
  delay
} from "rxjs/operators";
import { from, of } from "rxjs";

@Component({
  selector: 'app-switchmap',
  templateUrl: './switchmap.component.html',
  styleUrls: ['./switchmap.component.scss']
})


export class switchMapComponent  {
  
  
public example(operator: any) {
    from([0, 1, 2, 3, 4])
      .pipe(operator((x: any) => of(x).pipe(delay(500))))
      .subscribe(
        console.log,
        () => {},
        () => console.log(`${operator.name} completed`)
      );
  }

  public sm() {
    this.example(switchMap); // Output: 4
  }
}

