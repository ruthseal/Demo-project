import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService } from './in-memory-data.service';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';


import { DashboardComponent } from './dashboard/dashboard.component';
import { HeroDetailComponent } from './hero-detail/hero-detail.component';
import { HeroesComponent } from './heroes/heroes.component';

import { MessagesComponent } from './messages/messages.component';

import { ForkjoinComponent } from './forkJoin/forkjoin.component';

import { switchMapComponent } from './switchMap/switchmap.component';

import { CombineLatest } from './combineLatest/combinelatest.component';

import { mergeMapComponent } from './mergeMap/mergemap.component';



@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeroesComponent,
	HeroDetailComponent,
    MessagesComponent,
	ForkjoinComponent,
	switchMapComponent,
	HelloComponent,
	CombineLatest,
	mergeMapComponent
    
  ],
  imports: [
    BrowserModule,
	ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
	HttpClientInMemoryWebApiModule.forRoot(
      InMemoryDataService, { dataEncapsulation: false }
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
