import { Component, OnInit } from '@angular/core';
import { forkJoin, Observable, of } from 'rxjs';

@Component({
  selector: 'app-forkjoin',
  templateUrl: './forkjoin.component.html',
  styleUrls: ['./forkjoin.component.scss']
})
export class ForkjoinComponent implements OnInit {
  observables$: Observable<number[]> = of([1, 2, 3, 4, 5]);
  string$: Observable<string[]> = of(['Test', 'String']);
  constructor() { }
 
  ngOnInit(): void {
	//alert("HI");
    forkJoin([this.observables$, this.string$]).subscribe(data => {
      console.log(data);
    });
  }
}

