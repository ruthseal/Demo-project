
import {
  Component,
  ElementRef,
  Injectable,
  OnInit,
  VERSION,
  ViewChild,
} from '@angular/core';
import {
  debounceTime,
  distinctUntilChanged,
  fromEvent,
  map,
  mergeMap,
  switchMap,
  timer,
} from 'rxjs';
import { DataService } from '../data.service';

@Component({
  selector: 'app-mergemap',
  templateUrl: './mergemap.component.html',
  styleUrls: ['./mergemap.component.scss']
})


export class mergeMapComponent implements OnInit {
  
  @ViewChild('search', { static: true }) search: ElementRef;
  States: any[];
  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    fromEvent(this.search.nativeElement, 'input')
      .pipe(
        map((event: any) => event.target.value),
        switchMap((searchText: string) => this.dataService.getData(searchText))
      )
      .subscribe((res) => {
        this.States = res;
        console.log(res);
      });
  }
  
}

